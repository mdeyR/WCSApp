import React, { Component } from 'react';
import { Provider as PaperProvider } from 'react-native-paper'
import { ApplicationRouter } from './src/rithmComponents/ApplicationRouter'

export default class App extends Component {
  render() {
    return (
      <PaperProvider>
        <ApplicationRouter />
      </PaperProvider>
    );
  }
}