import { AsyncStorage } from 'react-native'
import moment from 'moment'

var RestRequester = {
  login: function (username, password) {
    return fetch('https://safe-test.rithm.eu/api/login', {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        username: username,
        password: password
      })
    })
  },
  logout: async function () {
    var token = await AsyncStorage.getItem('userToken')
    return fetch('https://safe-test.rithm.eu/api/employee/logout', {
      method: 'GET',
      headers: {
        'Authorization': token
      }
    })
  },
  getActiveAppointment: async function () {
    var url = 'https://safe-test.rithm.eu/api/appointment/getCurrentAppointment'
    var token = await AsyncStorage.getItem('userToken')
    return fetch(url, {
      method: 'GET',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'Authorization': token
      }
    })
  },
  getAppointmentList: async function (date) {
    var token = await AsyncStorage.getItem('userToken')

    return fetch('https://raw.githubusercontent.com/mdeyRithm/WCSApp/master/json/Appointment1.json', {
      method: 'GET',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'Authorization': token
      }
    })
  },
  getSearchList: async function (searchQuery) {
    let token = await AsyncStorage.getItem('userToken')
 /*+ searchQuery*/
    return fetch('https://raw.githubusercontent.com/mdeyRithm/WCSApp/master/json/SearchResults.json', {
      method: 'GET',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'Authorization': token
      }
    })
  },
}
export { RestRequester as default }
