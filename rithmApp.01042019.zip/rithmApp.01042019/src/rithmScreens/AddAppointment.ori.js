import React from 'react'
import { DatePickerAndroid, PermissionsAndroid, ScrollView, StyleSheet, View } from 'react-native'
import { Icon, Text, Divider } from 'react-native-elements'

import _ from 'lodash'
import Geocoder from 'react-native-geocoder'
import RNGooglePlaces from 'react-native-google-places'

import Colors from 'safe/constants/Colors'
import Dimensions from 'safe/constants/Dimensions'

import Loader from 'safe/components/Loader'
import PrimaryButton from 'safe/components/PrimaryButton'
import PrimarySolidButton from 'safe/components/PrimarySolidButton'
import SafeTextInput from 'safe/components/SafeTextInput'
import RestRequester from 'safe/api/RestRequester'
//import ActionUtils from 'safe/common/ActionUtils'

import moment from 'moment'

export default class AddAppointment extends React.Component {
  static navigationOptions = {
    title: 'Add Appointment',
    headerStyle: {
      backgroundColor: Colors.tintColor
    },
    headerTintColor: Colors.tintLightColor
  };
  constructor () {
    super()
    this.state = {
      appointmentId: null,
      address: '',
      postal: '',
      city: '',
      comment: '',
      additionalInfo: '',
      error: '',
      selectedDate: moment(),
      showCalendar: false,
      showLoading: false
    }
  }

  componentDidMount () {
    var appointment = this.props.navigation.state.params.appointment
    if (appointment) {
      this.setState({
        appointmentId: appointment.appointmentId,
        address: appointment.addressDTO.address,
        postal: appointment.addressDTO.postalCode,
        city: appointment.addressDTO.city,
        additionalInfo: appointment.addressDTO.additionalInfo,
        comment: appointment.comment,
        selectedDate: appointment.scheduledStart ? moment(appointment.scheduledStart) : this.props.navigation.state.params.selectedDate })
    } else {
      this.setState({ selectedDate: this.props.navigation.state.params.selectedDate })
    }
  }
  
  _requestLocationPermission = async () => {
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        {
          'title': 'SAFE App permission',
          'message': 'SAFE App needs access to your location ' +
                     'so we can help you retrieve current address.'
        }
      )
      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        this._onGetLocation()
      } else {
        console.log('Location permission denied')
      }
    } catch (err) {
      console.warn(err)
    }
  }

  _getAddressFromLatLong (lat, lng) {
    Geocoder.geocodePosition({
      lat,
      lng
    }).then(
      res => {
        this.setState({ address: res[0].streetName + ' ' + res[0].streetNumber }, console.log(this.state.address))
        this.setState({ postal: res[0].postalCode })
        this.setState({ city: res[0].locality })
      }
    )
  }
  _onGetLocation = () => {
    this.setState({ showLoading: true })
    navigator.geolocation.getCurrentPosition(
      (position) => {
        console.log('lat: ' + position.coords.latitude)
        var lat = position.coords.latitude
        var lng = position.coords.longitude
        this._getAddressFromLatLong(lat, lng)
        this.setState({
          error: null,
          showLoading: false
        })
      },
      (error) => {
        this.setState({
          error: error.message,
          showLoading: false
        }, () => {
          console.log('error getting location: ' + this.state.error)
        })
      },
      { enableHighAccuracy: true, timeout: 60000, maximumAge: 0 }
    )
  }

  _openSearchModal = () => {
    RNGooglePlaces.openAutocompleteModal({
      type: 'address',
      country: 'NL'
    })
      .then((place) => {
        console.log(place)
        this._getAddressFromLatLong(place.latitude, place.longitude)
        // place represents user's selection from the
        // suggestions and it is a simplified Google Place object.
      })
      .catch(error => console.log(error.message)) // error is a Javascript Error object
  }

  _onSaveAppointment = () => {
    console.log('saving appointment: ' + this.state.appointmentId)
    this.setState({ showLoading: true })
    var address = {
      address: this.state.address,
      postalCode: this.state.postal,
      additionalInfo: this.state.additionalInfo,
      city: this.state.city
    }

    var appointment = {
      appointmentId: this.state.appointmentId,
      scheduledStart: this.state.selectedDate.toDate(),
      scheduledEnd: this.state.selectedDate.toDate(),
      addressDTO: address,
      employeeDTO: null,
      rating: 0,
      comment: this.state.comment
    }

    if (this.state.appointmentId) {
      RestRequester.updateAppointment(appointment)
        .then(response => response.json())
        .then(response => {
          console.log('insert appointment')
          console.log(response)
          this.setState({
            showLoading: false
          })
          this.props.navigation.popToTop()
        })
    } else {
      RestRequester.insertAppointment(appointment)
        .then(response => response.json())
        .then(response => {
          console.log('insert appointment')
          console.log(response)
          this.setState({
            showLoading: false
          })
          this.props.navigation.popToTop()
        })
    }
  }

  _showDatePicker = async () => {
    try {
      const { action, year, month, day } = await DatePickerAndroid.open({
        // Use `new Date()` for current date.
        // May 25 2020. Month 0 is January.
        date: this.state.selectedDate.toDate(),
        minDate: new Date()
      })
      if (action !== DatePickerAndroid.dismissedAction) {
        // Selected year, month (0-11), day
        var selected = moment()
        selected.set('year', year)
        selected.set('month', month)
        selected.set('date', day)
        this.setState({ selectedDate: selected })
      }
    } catch ({ code, message }) {
      console.warn('Cannot open date picker', message)
    }
  }

  render () {
    return (
      <ScrollView
        style={ styles.container }
        behavior="padding">
        <Loader loading={ this.state.showLoading }/>
        <View style={ styles.locationContainer }>
          <PrimaryButton
            icon='search'
            title='FIND LOCATION'
            onPress={ this._openSearchModal }
            containerViewStyle = {styles.col5}/>
          <PrimaryButton
            icon='my-location'
            title='GET LOCATION'
            onPress={ this._requestLocationPermission }
            containerViewStyle = {styles.col5}/>
        </View>
        <View style={ styles.fieldContainer }>
          <Icon name='location-on' containerStyle={ styles.col1 } />
          <View style={ styles.col9 }>
            <SafeTextInput
              placeholder="Address"
              value={ this.state.address }
              onChangeText={(value) => this.setState({ address: value })}
            />
            <View style={ styles.fieldContainer }>
              <SafeTextInput
                style={ styles.col5 }
                placeholder="Postal"
                value={ this.state.postal }
                onChangeText={(value) => this.setState({ postal: value })}
              />
              <SafeTextInput
                style={ styles.col5 }
                placeholder="City"
                value={ this.state.city }
                onChangeText={(value) => this.setState({ city: value })}
              />
            </View>
            <SafeTextInput
              placeholder="Floor/Room Number"
              value={ this.state.additionalInfo }
              onChangeText={(value) => this.setState({ additionalInfo: value }) }
            />
          </View>
        </View>
        <Divider />
        <View style={ styles.fieldContainer }>
          <Icon name='event' containerStyle={ styles.col1 } />
          <View style={ styles.col8 }>
            <Text style={styles.date}>{this.state.selectedDate ? this.state.selectedDate.format('LL') : moment().format('LL')}</Text>
          </View>
          <Icon name='edit' containerStyle={ [styles.col1, styles.endIcon] } onPress={ () => this._showDatePicker() } />
        </View>
        <Divider />
        <View style={ styles.fieldContainer }>
          <Icon name='comment' containerStyle={ styles.col1 } />
          <View style={ styles.col9 }>
            <SafeTextInput
              placeholder="Comment"
              value={ this.state.comment }
              onChangeText={(value) => this.setState({ comment: value }) }
            />
          </View>
        </View>
        <PrimarySolidButton
          title="Save"
          onPress = { () => this._onSaveAppointment() }
        />
      </ScrollView>
    )
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 15,
    backgroundColor: Colors.background
  },
  locationContainer: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-around'
  },
  fieldContainer: {
    flex: 1,
    flexDirection: 'row'
  },
  date: {
    margin: Dimensions.defaultMargin
  },
  endIcon: {
    marginEnd: Dimensions.defaultMargin
  },
  col1: {
    flex: 0.1
  },
  col5: {
    flex: 0.5
  },
  col8: {
    flex: 0.8
  },
  col9: {
    flex: 0.9
  }
})
