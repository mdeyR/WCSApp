import React, { Component } from "react";
import { View, Image } from "react-native";
import { Headline } from 'react-native-paper';

import CommonStyles from '../styling/CommonStyles';

class NeedHelp extends Component {

  static navigationOptions = {
    header: null,
  };

  render() {
    return (
      <View style={CommonStyles.container}>

        <Image source={require('../images/wcs-group.jpg')} />
        <Headline>Under Construction....</Headline>

      </View >
    )
  }
}

export default NeedHelp;