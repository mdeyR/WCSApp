import React, { Component } from "react";
import { AsyncStorage, View, Image } from "react-native";
import { withTheme, Text, TextInput, Button, TouchableRipple } from 'react-native-paper';
import Icon from 'react-native-vector-icons/FontAwesome';

import CommonStyles from '../styling/CommonStyles';

class SignIn extends Component {

  static navigationOptions = {
    header: null,
  };

  render() {
    return (
      <View style={CommonStyles.container}>

        <Image source={require('../images/wcs-group.jpg')} />

        <View style={CommonStyles.cardContainer}>
          <View style={CommonStyles.iconInputContainer}>
            <Icon name='user' size={20} />
            <TextInput label='user name' style={CommonStyles.inputField} />
          </View>
          <View style={CommonStyles.iconInputContainer}>
            <Icon name='key' size={20} />
            <TextInput label='password' secureTextEntry={true} style={CommonStyles.inputField} />
          </View>
          <Button onPress={() => this._signInAsync()}>
            login
          </Button>
        </View>

        <View style={CommonStyles.iconInputContainer}>
          <TouchableRipple onPress={() => this._gotoSignUp()} rippleColor={this.props.theme.primary}>
            <Text style={CommonStyles.linkText1}>Sign Up</Text>
          </TouchableRipple>
          <TouchableRipple onPress={() => this._needHelp()} rippleColor={this.props.theme.primary} style={{ direction: 'rtl' }}>
            <Text style={CommonStyles.linkText1}>Need help?</Text>
          </TouchableRipple>
        </View>
      </View >
    )
  }

  _signInAsync = async () => {
    await AsyncStorage.setItem('userToken', 'John Doe')
    this.props.navigation.navigate('App')
  }

  _gotoSignUp() {
    this.props.navigation.navigate('SignUp')
  }

  _needHelp() {
    this.props.navigation.navigate('NeedHelp')
  }
}

export default withTheme(SignIn);