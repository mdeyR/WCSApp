import React from 'react'
import { DatePickerAndroid, ScrollView, View } from 'react-native'
import { Icon, Divider } from 'react-native-elements'
import { Appbar, Text, TextInput } from 'react-native-paper';
import moment from 'moment'

import Loader from '../safe/Loader'
import PrimarySolidButton from '../safe/PrimarySolidButton'

import RestRequester from '../api/RestRequester'
import CommonStyles from '../styling/CommonStyles'
import SearchBar from '../rithmComponents/SearchBar'


export default class AddAppointment extends React.Component {

  static navigationOptions = ({ navigation }) => {
    const params = navigation.state.params || {}
    return {
      header: params.headerBar,
    }
  }

  _setNavigationParams = () => {
    let headerBar = (
      <Appbar.Header>
        <Appbar.BackAction onPress={this._goBack} />
        <Appbar.Content title={"Add An Appointment"} />
      </Appbar.Header>
    )

    this.props.navigation.setParams({ headerBar })
  }

  constructor() {
    super()
    this.state = {
      appointmentId: '',
      location: '',
      start: moment(),
      end: moment(),
      fromLanguage: '',
      toLanguage: '',
      domain: '',
      experience: '',
      tariff: '',
    }
  }

  componentDidMount() {
    this._setNavigationParams()

    var appointment = this.props.navigation.state.params.appointment
    console.log('appointment')
    console.log(appointment)

    if (appointment) {
      this.setState({
        appointmentId: appointment.appointmentId,
        location: appointment.location,
        start: appointment.start,
        end: appointment.end,
        fromLanguage: appointment.fromLanguage,
        toLanguage: appointment.toLanguage,
        domain: appointment.domain,
        experience: appointment.expereince,
        tariff: appointment.tariff,
      })
    }
  }

  _onSaveAppointment = () => {
    console.log('saving appointment: ' + this.state.appointmentId)
    this.setState({ showLoading: true })
    var address = {
      address: this.state.address,
      postalCode: this.state.postal,
      additionalInfo: this.state.additionalInfo,
      city: this.state.city
    }

    var appointment = {
      appointmentId: this.state.appointmentId,
      scheduledStart: this.state.selectedDate.toDate(),
      scheduledEnd: this.state.selectedDate.toDate(),
      addressDTO: address,
      employeeDTO: null,
      rating: 0,
      comment: this.state.comment
    }

    if (this.state.appointmentId) {
      RestRequester.updateAppointment(appointment)
        .then(response => response.json())
        .then(response => {
          console.log('insert appointment')
          console.log(response)
          this.setState({
            showLoading: false
          })
          this.props.navigation.popToTop()
        })
    } else {
      RestRequester.insertAppointment(appointment)
        .then(response => response.json())
        .then(response => {
          console.log('insert appointment')
          console.log(response)
          this.setState({
            showLoading: false
          })
          this.props.navigation.popToTop()
        })
    }
  }

  _showDatePicker = async () => {
    try {
      const { action, year, month, day } = await DatePickerAndroid.open({
        // Use `new Date()` for current date.
        // May 25 2020. Month 0 is January.
        date: this.state.selectedDate.toDate(),
        minDate: new Date()
      })
      if (action !== DatePickerAndroid.dismissedAction) {
        // Selected year, month (0-11), day
        var selected = moment()
        selected.set('year', year)
        selected.set('month', month)
        selected.set('date', day)
        this.setState({ selectedDate: selected })
      }
    } catch ({ code, message }) {
      console.warn('Cannot open date picker', message)
    }
  }

  render() {
    return (
      <ScrollView behavior="padding">
        <View style={CommonStyles.container}>
          <SearchBar results={this._forwardSearchResults} />
          {/* <Loader loading={this.state.showLoading} /> */}

          <TextInput label='Name' style={CommonStyles.inputField}  />
          <Divider />
          <TextInput label='Start' style={CommonStyles.inputField} />
          <Icon name='edit' onPress={ () => this._showDatePicker() } />

          <TextInput label='End' style={CommonStyles.inputField} />
          <Divider />
          <TextInput label='Language From' style={CommonStyles.inputField} />
          <TextInput label='Language To' style={CommonStyles.inputField} />
          <Divider />
          <TextInput label='Domain' style={CommonStyles.inputField} />
          <TextInput label='Experience' style={CommonStyles.inputField} />
          <TextInput label='Tariff' style={CommonStyles.inputField} />

          <PrimarySolidButton
            title = "Save"
            //onPress = { () => this._saveAppointment() }
            onPress={() => console.log('Saving Appointment')}
          />
        </View>
      </ScrollView>
    )
  }

  _getUserAsync = async () => {
    try {
      return await AsyncStorage.getItem('userToken')
    } catch (error) {
      console.log(error.message)
    }
  }

  _goBack = () => {
    this.props.navigation.goBack()
  }
  
  _saveAppointment = results => {
    //Database Call
    this._goBack
  }
}