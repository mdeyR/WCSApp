import React from 'react'
import { FlatList, RefreshControl, StyleSheet, View } from 'react-native'
import { Icon } from 'react-native-elements'
import moment from 'moment'

import Colors from '../constants/Colors'
import AppointmentRow from '../rithmComponents/AppointmentRow'
import CalendarStrip from '../safe/CalendarStrip'
import RestRequester from '../api/RestRequester'

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background
  },
  rightIcon: {
    marginEnd: 16
  }
})

export default class AppointmentList extends React.Component {
  static navigationOptions = ({ navigation }) => {
    const params = navigation.state.params || {}

    return {
      title: params.title,
      headerRight: params.headerRight,
      headerStyle: params.headerStyle,
      headerTintColor: params.headerTintColor
    }
  }

  constructor(props) {
    super(props)
    this.state = {
      loading: false,
      appointments: [],
      selectedDate: moment(),
      activeAppointment: null
    }
  }

  componentDidMount() {
    this._setNavigationParams()
    this._getAppointmentList()
  }

  _setNavigationParams = () => {
    let title = 'My Appointments'
    let headerRight =
      <Icon
        name='add'
        color={Colors.tintLightColor}
        containerStyle={styles.rightIcon}
        onPress={
          () => {
            this.props.navigation.navigate('AddAppointment', { selectedDate: this.state.selectedDate })
          }
        }
        underlayColor={Colors.underlayHeader} />
    let headerStyle = {
      backgroundColor: Colors.tintColor
    }
    let headerTintColor = Colors.tintLightColor

    this.props.navigation.setParams({
      title,
      headerRight,
      headerStyle,
      headerTintColor
    })
  }

  _getAppointmentList = (date) => {
    this.setState({ loading: true })

    RestRequester.getAppointmentList(date)
      .then(response => response.json())
      .then(responseJson => {
        this.setState({
          appointments: responseJson.appointmentList,
          loading: false
        })
      })
  }

  _onEditPress = (appointment) => {
    console.log('onEditPress, appointment: ')
    console.log(appointment)
    this.props.navigation.navigate('AddAppointment', { selectedDate: moment(appointment.scheduledStart), appointment: appointment })
  }

  _renderItem = ({ item }) => {
    return (
      <AppointmentRow
        appointment = {item}
      />
    )
  }

  _onDateClicked = (selectedDate) => {
    this.setState({ selectedDate: selectedDate })
    this._getAppointmentList(selectedDate)
  }

  render() {
    return (
      <View style = {styles.container}>
        <CalendarStrip onDateClicked = {this._onDateClicked} />

        <FlatList
          data = {this.state.appointments}
          renderItem = {this._renderItem}
          keyExtractor = {item => item.id.toString()}
          refreshControl = {
            <RefreshControl
              tintColor = {Colors.tintColor}
              colors = {[Colors.tintColor]}
              refreshing = {this.state.loading}
              onRefresh = {this._getAppointmentList}
            />
          } />
      </View>
    )
  }
}