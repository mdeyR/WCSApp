import React, { Component } from 'react'
import { AsyncStorage, Text, View, FlatList } from 'react-native'
import { Appbar } from 'react-native-paper';


export default class SearchResults extends Component {

  static navigationOptions = ({ navigation }) => {
    const params = navigation.state.params || {}

    return {
      header: params.headerBar,
    }
  }

  _setNavigationParams = () => {
    this._getUserAsync().then(userToken => {
      let headerBar = (
        <Appbar.Header>
          <Appbar.Content title={"Welcome " + userToken} />
          <Appbar.Action icon='exit-to-app' onPress={this._signOutAsync} />
        </Appbar.Header>
      )

      this.props.navigation.setParams({ headerBar })
    })
  }

  componentDidMount() {
    console.log('In SearchResults')
    console.log(this.props.navigation.state.params.results)
    this._setNavigationParams()
  }

  render() {
    return (
      <View>
        <FlatList
          data={this.props.navigation.state.params.results}
          renderItem = {({ item }) => <Text>{item.toString()}</Text>}
        />
      </View>
    )
  }

  _getUserAsync = async () => {
    try {
      return await AsyncStorage.getItem('userToken')
    } catch (error) {
      console.log(error.message)
    }
  }
}


/*
      <List containerStyle={{ borderTopWidth: 0, borderBottomWidth: 0 }}>
        <FlatList
          data={this.props.navigation.state.params.results}
          renderItem={({ item }) => (
            <ListItem
              //roundAvatar
              title={`${item}`}
              subtitle={item.email}
              avatar={{ uri: item.picture.thumbnail }}
              containerStyle={{ borderBottomWidth: 0 }}
              />
              )}
              keyExtractor={item => item.email}
              ItemSeparatorComponent={this.renderSeparator}
              ListHeaderComponent={this.renderHeader}
              ListFooterComponent={this.renderFooter}
              onRefresh={this.handleRefresh}
              refreshing={this.state.refreshing}
              onEndReached={this.handleLoadMore}
              onEndReachedThreshold={50}
            />
          </List>
          */