import React, { Component } from "react";
import { AsyncStorage, View, TouchableOpacity, Image } from "react-native";
import { Appbar, Text } from 'react-native-paper';

import CommonStyles from '../styling/CommonStyles';
import SearchBar from '../rithmComponents/SearchBar'

class HomeScreen extends Component {

  static navigationOptions = ({ navigation }) => {
    const params = navigation.state.params || {}

    return {
      header: params.headerBar,
    }
  }

  componentDidMount() {
    this._setNavigationParams()
  }

  _setNavigationParams = () => {
    this._getUserAsync().then(userToken => {
      let headerBar = (
        <Appbar.Header>
          <Appbar.Content title={"Welcome " + userToken} />
          <Appbar.Action icon='exit-to-app' onPress={this._signOutAsync} />
        </Appbar.Header>
      )

      this.props.navigation.setParams({ headerBar })
    })
  }

  render() {
    return (
      <View style={CommonStyles.containerHome}>

        <SearchBar results={this._forwardSearchResults} />

        <TouchableOpacity style={CommonStyles.bigIcon} onPress={this._goToCalendar}>
          <Image source={require('../images/twotone_calendar_today_black_48dp.png')} />
          <Text>Go to Calendar</Text>
        </TouchableOpacity>
        <TouchableOpacity style={CommonStyles.bigIcon} onPress={this._goToCalendar}>
          <Image source={require('../images/twotone_call_black_48dp.png')} />
          <Text>Call WCS</Text>
        </TouchableOpacity>
      </View>
    );
  }

  _getUserAsync = async () => {
    try {
      return await AsyncStorage.getItem('userToken')
    } catch (error) {
      console.log(error.message)
    }
  }

  _signOutAsync = async () => {
    await AsyncStorage.clear();
    this.props.navigation.navigate('Auth');
  }

  _goToCalendar = () => {
    this.props.navigation.navigate('Appointments')
  }

  _forwardSearchResults = results => {
    this.props.navigation.navigate('SearchResults', { results: results })
  }
}

export default HomeScreen