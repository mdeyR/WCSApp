import React, { Component } from "react";
import {
    ActivityIndicator,
    AsyncStorage,
    ImageBackground,
    View,
} from 'react-native';

import CommonStyles from '../styling/CommonStyles';
import CustomStatusBar from '../rithmComponents/CustomStatusBar';

class AuthLoadingScreen extends Component {
    constructor(props) {
        super(props);
        this._bootstrapAsync();
    }

    // Fetch the token from storage then navigate to our appropriate place
    _bootstrapAsync = async () => {
        const userToken = await AsyncStorage.getItem('userToken');

        // This will switch to the App screen or Auth screen and this loading
        // screen will be unmounted and thrown away.
        this.props.navigation.navigate(userToken ? 'App' : 'Auth');
    };

    // Render any loading content that you like here
    render() {
        return (
            <ImageBackground source={require('../images/terminal-1210006_1920.jpg')} style={{ width: '100%', height: '100%' }}>
                <View style={CommonStyles.container}>
                    <CustomStatusBar {...CommonStyles.statusBar} />

                    <ActivityIndicator />
                </View>
            </ImageBackground>
        );
    }
}

export default AuthLoadingScreen