import React, { Component } from "react";
import { View, Image } from "react-native";
import { Headline } from 'react-native-paper';

import CommonStyles from '../styling/CommonStyles';

export default class Finance extends Component {
  render() {
    return (
      <View style={CommonStyles.container}>

        <Image source={require('../images/wcs-group.jpg')} />
        <Headline>Finance under Construction....</Headline>

      </View >
    )
  }
}
