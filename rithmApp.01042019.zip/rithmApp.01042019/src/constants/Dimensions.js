export default {
  defaultMargin: 16,
  buttonPadding: 12,
  buttonBorderWidth: 1
}
