const primaryColor = '#6200ee'
const primaryDark = '#f6f6f6'

export default {
  primary: primaryColor,
  underlayHeader: primaryDark,
  transparentBg: '#00000040',
  background: '#ffffff',
  tintLightColor: '#ffffff',
  tintColor: primaryColor,
  tabIconDefault: '#ccc',
  tabIconSelected: primaryColor,
  tabBar: '#fefefe',
  errorBackground: 'red',
  errorText: '#fff',
  warningBackground: '#EAEB5E',
  warningText: '#666804',
  noticeBackground: primaryColor,
  noticeText: '#fff',
  textColor: '#525151'
}
