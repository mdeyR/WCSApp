import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'space-between',
  },
  iconInputContainer: {
    flexDirection: 'row',
    padding: 5,
    alignItems: 'center',
    justifyContent: 'space-evenly',
  },
  inputField: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  cardContainer: {
    elevation: 10,
    marginLeft: 30,
    marginRight: 30,
    marginTop: 10,
    backgroundColor: '#fff',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.5,
    paddingTop: 10,
    paddingBottom: 20,
    borderRadius: 10,
  },
  linkText1: {
    flex: -1,
    fontSize: 16,
    fontFamily: 'Rubik-Regular',
    color: '#3366BB' //Blue
  },
  searchBar: {
    margin: 10,
    paddingLeft: 5,
    borderRadius: 10,
  },
  containerHome: {
    flex: 1,
    justifyContent: 'space-between',
    marginBottom: '30%',
  },
  bigIcon: {
    minWidth: '25%',
    minHeight: '20%',
    alignSelf: 'center',
  }
})

export const CustomStyles = {
  statusBar: {
    bgColor: '#4f9a94',
    barStyle: 'light-content',
  }
}