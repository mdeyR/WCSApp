import React from 'react';
import { View, StatusBar } from 'react-native';

import { CustomStyles } from '../styling/CommonStyles';

const CustomStatusBar = () => (
    <View>
        <StatusBar
            translucent
            backgroundColor = {CustomStyles.statusBar.bgColor}
            barStyle = {CustomStyles.statusBar.barStyle}
        />
    </View>
);

export default CustomStatusBar;