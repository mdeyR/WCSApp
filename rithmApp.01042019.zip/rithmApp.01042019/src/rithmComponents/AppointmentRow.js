import React from 'react'
import PropTypes from 'prop-types'
import { StyleSheet, View } from 'react-native'
import { Divider } from 'react-native-elements'

import PrimaryButton from '../safe/PrimaryButton'
import AppointmentView from '../rithmComponents/AppointmentView'

import Dimensions from '../constants/Dimensions'

export default class AppointmentRow extends React.Component {
  static get propTypes () {
    return {
      appointment: PropTypes.object,
      onEditPress: PropTypes.func,
      onStartPress: PropTypes.func
    }
  }

  render () {
    return (
      <View style = { styles.container }>
        <AppointmentView appointment = { this.props.appointment } />
        <View style = { styles.btnContainer }>
          <PrimaryButton title='EDIT' />
        </View>
        <Divider />
      </View>
    )
  }
}

const styles = StyleSheet.create({
  btnContainer: {
    flex: 1,
    flexDirection: 'row',
    marginLeft: 'auto'
  },
  container: {
    marginBottom: Dimensions.defaultMargin
  }
})
