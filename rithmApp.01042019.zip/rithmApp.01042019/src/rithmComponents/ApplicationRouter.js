
import { createSwitchNavigator, createStackNavigator, createBottomTabNavigator, createAppContainer } from 'react-navigation';

import SignIn from '../rithmScreens/SignIn'
import SignUp from '../rithmScreens/SignUp'
import NeedHelp from '../rithmScreens/NeedHelp'
import AppointmentList from '../rithmScreens/AppointmentList'
import AddAppointment from '../rithmScreens/AddAppointment'
import Home from '../rithmScreens/Home'
import SearchResults from '../rithmScreens/SearchResults'
import Contacts from '../rithmScreens/Contacts'
import Finances from '../rithmScreens/Finances'
import Settings from '../rithmScreens/Settings'
import AuthLoadingScreen from '../rithmScreens/AuthLoadingScreen'

const AuthStack = createStackNavigator({ SignIn: SignIn, SignUp: SignUp, NeedHelp: NeedHelp });
const HomeStack = createStackNavigator(
  { Home: Home, SearchResults: SearchResults, Appointments: AppointmentList, AddAppointment: AddAppointment },

)
const AppStack = createBottomTabNavigator(
  { Home: HomeStack, Contacts: Contacts, Finance: Finances, Settings: Settings },
  {
    navigationOptions: ({ navigation }) => {
      const { routeName } = navigation.state.routes[navigation.state.index];
      return {
        headerTitle: routeName
      };
    },
  },
)

const AppNavigator = createSwitchNavigator(
  {
    AuthLoading: AuthLoadingScreen,
    Auth: AuthStack,
    App: AppStack,
  },
  {
    initialRouteName: 'AuthLoading',
  }
)

export const ApplicationRouter = createAppContainer(AppNavigator)