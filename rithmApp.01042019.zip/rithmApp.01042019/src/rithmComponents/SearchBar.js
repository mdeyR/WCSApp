import React from 'react'
import PropTypes from 'prop-types'
import { StyleSheet, View } from 'react-native'
import { Divider } from 'react-native-elements'
import { Searchbar, List } from 'react-native-paper'

import CommonStyles from '../styling/CommonStyles'
import RestRequester from '../api/RestRequester'

export default class SearchBar extends React.Component {
  state = {
    firstQuery: '',
    showLoading: false,
    userList: [],
  };

  render() {
    const { firstQuery } = this.state;

    return (
      <Searchbar
        placeholder="Name or Language"
        onChangeText={query => { this.setState({ firstQuery: query }); }}
        value={firstQuery}
        style={CommonStyles.searchBar}
        onIconPress={this._goToSearchResults}
      />
    )
  }

  _goToSearchResults = () => {
    console.log('Searching: ' + this.state.firstQuery)
    this.setState({
      showLoading: true
    })

    RestRequester.getSearchList(this.state.firstQuery)
      .then(response => response.json())
      .then(responseJson => {
        this.setState({
          userList: responseJson.userName,
          showLoading: false
        }, () => this.props.results(this.state.userList)
        )
    })
  }
}
