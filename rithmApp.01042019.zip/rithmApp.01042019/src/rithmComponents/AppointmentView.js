import React from 'react'
import PropTypes from 'prop-types'
import { StyleSheet, Text, View } from 'react-native'
import { Card, Icon, Divider, Button } from 'react-native-elements'

import moment from 'moment'

import Dimensions from '../constants/Dimensions'
import Colors from '../constants/Colors'

export default class AppointmentCard extends React.Component {
  static get propTypes () {
    return {
      appointment: PropTypes.object
    }
  }

  render () {
    var date = moment(this.props.appointment.date)
    return (
      <View>
        <View style = {styles.container}>
          <View style = {styles.dateContainer}>
            <Text style = {[styles.dateText, styles.title]}>{ date.format('ddd') }</Text>
            <Text style = {styles.dateText}>{ date.format('ll') }</Text>
          </View>
          <View style={ styles.divider } />
          <View style={styles.addressContainer}>
            <Text style={styles.title}>{ this.props.appointment.location }</Text>
            <Text style={styles.title}>{ this.props.appointment.attendedBy }</Text>
          </View>
        </View>
      </View>
    )
  }
}

const styles = StyleSheet.create({
  addressContainer: {
    paddingStart: 10,
    flex: 0.75
  },
  container: {
    flexDirection: 'row',
    // justifyContent: 'space-between',
    marginLeft: Dimensions.defaultMargin,
    marginRight: Dimensions.defaultMargin
  },
  dateContainer: {
    flex: 0.25
  },
  dateText: {
    textAlign: 'left'
  },
  divider: {
    height: 100,
    width: 1,
    backgroundColor: Colors.tintColor
  },
  textContainer: {
    alignItems: 'center',
    flex: 1,
    flexDirection: 'row'
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold'
  }
})
