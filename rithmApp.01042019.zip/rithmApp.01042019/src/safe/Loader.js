import React from 'react'
import {
  StyleSheet,
  View,
  Modal,
  ActivityIndicator
} from 'react-native'
import Colors from '../constants/Colors'

const Loader = props => {
  const {
    loading,
    ...attributes
  } = props

  return (
    <Modal
      transparent={true}
      animationType={'none'}
      visible={loading}
      onRequestClose={() => { console.log('close modal') }}>
      <View style={styles.modalBackground}>
        <ActivityIndicator
          animating={loading}
          color={ Colors.tintColor }
          size='large' />
      </View>
    </Modal>
  )
}

const styles = StyleSheet.create({
  modalBackground: {
    flex: 1,
    alignItems: 'center',
    flexDirection: 'column',
    justifyContent: 'space-around',
    backgroundColor: Colors.transparentBg
  }
})

export default Loader
