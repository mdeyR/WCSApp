import React, { Component } from 'react'
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native'
import { Icon } from 'react-native-elements'

import PropTypes from 'prop-types'

import Colors from '../constants/Colors'
import Dim from '../constants/Dimensions'

class PrimaryButton extends Component {
  static get propTypes () {
    return {
      title: PropTypes.string,
      icon: PropTypes.string,
      onPress: PropTypes.func
    }
  }
  render () {
    return (
      <View style={ styles.container }>
        <TouchableOpacity
          style={styles.button}
          onPress={this.props.onPress} >
          {this.props.icon &&
          <Icon
            style={ styles.icon }
            name={ this.props.icon }
            size={16}
            color={ Colors.primary }/>}
          <Text style={styles.title}>{ this.props.title }</Text>
        </TouchableOpacity>
      </View>
    )
  }
}

const styles = StyleSheet.create({
  button: {
    borderRadius: 50,
    borderWidth: Dim.buttonBorderWidth,
    borderColor: Colors.primary,
    margin: Dim.defaultMargin,
    padding: Dim.buttonPadding,
    flexDirection: 'row',
    justifyContent: 'center'
  },
  container: {
    margin: 0
  },
  icon: {
    marginLeft: Dim.buttonPadding,
    marginRight: Dim.buttonPadding
  },
  title: {
    color: Colors.primary,
    marginLeft: Dim.buttonPadding,
    marginRight: Dim.buttonPadding,
    textAlign: 'center'
  }
})
export default PrimaryButton
