import React from 'react'
import PropTypes from 'prop-types'
import { FlatList, StyleSheet, Text, View } from 'react-native'
import { ListItem, Avatar } from 'react-native-elements'

import moment from 'moment'

import Colors from '../constants/Colors'
import Dimensions from '../constants/Dimensions'

export default class CalendarStrip extends React.Component {
  state={
    selectedDateIndex: 0
  }

  static get propTypes () {
    return {
      onDateClicked: PropTypes.func
    }
  }

  _renderItem = ({ item }) => {
    return (
      <ListItem
        key={ item.key }
        hideChevron
        showsHorizontalScrollIndicator={false}
        avatar={<Avatar size="small"
          rounded
          title={ item.value.format('DD') }
          onPress={() => {
            this.setState({ selectedDateIndex: item.key })
            this.props.onDateClicked(item.value)
          }}

          overlayContainerStyle={item.key === this.state.selectedDateIndex ? styles.selected : styles.notSelected}
          activeOpacity={0.7} />}
      />
    )
  }

  _enumerateDaysBetweenDates = function (startDate, endDate) {
    var dates = []

    var currDate = moment(startDate).startOf('day')
    var lastDate = moment(endDate).startOf('day')
    var i = 0
    do {
      dates.push({ key: i, value: currDate.clone() })
      i++
    } while (currDate.add(1, 'days').diff(lastDate) < 0)

    return dates
  }

  render () {
    var now = moment().startOf('day')
    var endOfMonth = moment().endOf('month')

    var dates = this._enumerateDaysBetweenDates(now, now.clone().add(7, 'days'))
    if (endOfMonth.diff(now, 'days') < 7) {
      var nextMonth = moment().add(1, 'months').format('MMMM')
    }

    var month = now.format('MMMM')
    var monthString = month
    monthString += nextMonth ? ` - ${nextMonth}` : ''

    return (
      <View style={ styles.container } zIndex={ 10 } >
        <Text>{ monthString }</Text>
        <FlatList
          data ={ dates }
          renderItem={this._renderItem}
          keyExtractor={item => item.key.toString()}
          horizontal={ true } />
      </View>
    )
  }
}

const styles = StyleSheet.create({
  container: {
    padding: Dimensions.defaultMargin
  },
  selected: {
    backgroundColor: Colors.primary
  },
  notSelected: {
    backgroundColor: Colors.tabIconDefault
  }
})
