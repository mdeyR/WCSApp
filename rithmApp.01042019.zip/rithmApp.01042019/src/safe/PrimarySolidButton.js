import React, { Component } from 'react'
import { Button, StyleSheet, Text, TouchableOpacity, View } from 'react-native'
import { Icon } from 'react-native-elements'
import PropTypes from 'prop-types'

// import { Button } from 'react-native-elements'
import Colors from '../constants/Colors'
import Dim from '../constants/Dimensions'

class PrimarySolidButton extends Component {
  static get propTypes () {
    return {
      title: PropTypes.string,
      icon: PropTypes.string,
      onPress: PropTypes.func
    }
  }
  render () {
    return (
      <View style={ styles.container }>
        <TouchableOpacity
          style={styles.button}
          onPress={this.props.onPress}
        >
          {this.props.icon &&
          <Icon
            style={ styles.icon }
            name={ this.props.icon }
            size={16}
            color={ Colors.tintLightColor }/>}
          <Text style={styles.title}>{ this.props.title }</Text>
        </TouchableOpacity>
      </View>
    )
  }
}

const styles = StyleSheet.create({
  button: {
    backgroundColor: Colors.primary,
    borderRadius: 50,
    margin: Dim.defaultMargin,
    padding: Dim.buttonPadding,
    flexDirection: 'row',
    justifyContent: 'center'
  },
  container: {
    margin: 0
  },
  icon: {
    marginLeft: Dim.buttonPadding,
    marginRight: Dim.buttonPadding
  },
  title: {
    color: Colors.tintLightColor,
    marginLeft: Dim.buttonPadding,
    marginRight: Dim.buttonPadding
  },
  containerView: {
    marginLeft: Dim.defaultMargin,
    marginTop: Dim.defaultMargin,
    marginBottom: Dim.defaultMargin,
    marginRight: Dim.defaultMargin
  }
})
export default PrimarySolidButton
