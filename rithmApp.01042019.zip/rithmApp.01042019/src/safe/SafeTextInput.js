import React, { Component } from 'react'
import { StyleSheet, TextInput } from 'react-native'
import Colors from '../constants/Colors'
import Dim from '../constants/Dimensions'

class SafeTextInput extends Component {
  render () {
    return (
      <TextInput
        { ...this.props }
        underlineColorAndroid={ Colors.primary }
        style={ [styles.inputTxt, this.props.style] }
      />
    )
  }
}

const styles = StyleSheet.create({
  inputTxt: {
    margin: Dim.defaultMargin
  }
})

export default SafeTextInput
